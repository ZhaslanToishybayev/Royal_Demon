# 🚀 Инструкция по развертыванию Royal Demons v1.0

## 📋 Обзор

Этот документ содержит подробные инструкции по развертыванию и распространению игры Royal Demons v1.0.

---

## 🎯 Целевые платформы

### Поддерживаемые ОС
- ✅ **Linux** (Ubuntu 20.04+, Debian 10+)
- ✅ **Windows** (Windows 10+)
- ✅ **macOS** (macOS 10.15+)

### Системные требования
- **Java**: 21 или выше (OpenJDK рекомендован)
- **Память**: 512 MB RAM минимально, 1 GB рекомендовано
- **Процессор**: Dual-core 2.0 GHz+
- **Видеокарта**: Поддержка OpenGL 2.0+
- **Место на диске**: 100 MB свободного пространства

---

## 📦 Пакеты для распространения

### Вариант 1: Исходный код (для разработчиков)
```bash
# Клонирование репозитория
git clone https://github.com/your-username/royal-demons.git
cd royal-demons

# Сборка и запуск
./gradlew build
./gradlew run
```

### Вариант 2: JAR файл (для пользователей)
```bash
# Скачивание JAR файла
wget https://github.com/your-username/royal-demons/releases/download/v1.0/royal-demons.jar

# Запуск
java -jar royal-demons.jar
```

### Вариант 3: Полный дистрибутив (рекомендован)
```bash
# Скачивание дистрибутива
wget https://github.com/your-username/royal-demons/releases/download/v1.0/royal-demons-v1.0.tar.gz

# Распаковка
tar -xzf royal-demons-v1.0.tar.gz
cd royal-demons-v1.0

# Запуск
./run.sh
```

---

## 🔧 Установка Java

### Linux (Ubuntu/Debian)
```bash
# Обновление пакетов
sudo apt update

# Установка OpenJDK 21
sudo apt install openjdk-21-jdk

# Проверка установки
java -version
javac -version
```

### Linux (CentOS/RHEL/Fedora)
```bash
# Для Fedora
sudo dnf install java-21-openjdk java-21-openjdk-devel

# Для CentOS/RHEL
sudo yum install java-21-openjdk java-21-openjdk-devel

# Проверка установки
java -version
```

### Windows
1. Скачайте Java 21 с https://adoptium.net/
2. Запустите установщик
3. Добавьте Java в PATH (обычно автоматически)
4. Проверьте установку в командной строке:
```cmd
java -version
```

### macOS
```bash
# Через Homebrew
brew install openjdk@21

# Создание символической ссылки
sudo ln -sfn /usr/local/opt/openjdk@21/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk-21.jdk

# Добавление в PATH (добавьте в ~/.zshrc или ~/.bash_profile)
export JAVA_HOME=$(/usr/libexec/java_home -v 21)
export PATH="$JAVA_HOME/bin:$PATH"

# Проверка установки
java -version
```

---

## 🚀 Запуск игры

### Метод 1: Через Gradle (разработчики)
```bash
# Клонирование и сборка
git clone https://github.com/your-username/royal-demons.git
cd royal-demons
./gradlew build

# Запуск
./gradlew run
```

### Метод 2: Через JAR файл (пользователи)
```bash
# Скачивание и запуск
wget https://github.com/your-username/royal-demons/releases/download/v1.0/royal-demons.jar
java -jar royal-demons.jar
```

### Метод 3: Через скрипт (рекомендован)
```bash
# Для Linux/macOS
./run.sh

# Для Windows
run.bat
```

---

## 📝 Создание скриптов запуска

### Linux/macOS (run.sh)
```bash
#!/bin/bash

# Royal Demons v1.0 Launcher
# Проверка наличия Java
if ! command -v java &> /dev/null; then
    echo "Ошибка: Java не установлена"
    echo "Пожалуйста, установите Java 21 или выше"
    echo "https://adoptium.net/"
    exit 1
fi

# Проверка версии Java
JAVA_VERSION=$(java -version 2>&1 | head -n 1 | cut -d'"' -f2 | cut -d'.' -f1)
if [ "$JAVA_VERSION" -lt 21 ]; then
    echo "Ошибка: Требуется Java 21 или выше"
    echo "Текущая версия: $(java -version 2>&1 | head -n 1)"
    exit 1
fi

# Установка параметров JVM
JAVA_OPTS="-Xmx1G -Xms512M -Djava.awt.headless=false"

# Запуск игры
echo "Запуск Royal Demons v1.0..."
java $JAVA_OPTS -jar royal-demons.jar

# Проверка кода завершения
if [ $? -ne 0 ]; then
    echo "Ошибка при запуске игры"
    exit 1
fi
```

### Windows (run.bat)
```batch
@echo off
REM Royal Demons v1.0 Launcher

REM Проверка наличия Java
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo Ошибка: Java не установлена
    echo Пожалуйста, установите Java 21 или выше
    echo https://adoptium.net/
    pause
    exit /b 1
)

REM Установка параметров JVM
set JAVA_OPTS=-Xmx1G -Xms512M -Djava.awt.headless=false

REM Запуск игры
echo Запуск Royal Demons v1.0...
java %JAVA_OPTS% -jar royal-demons.jar

REM Проверка кода завершения
if %errorlevel% neq 0 (
    echo Ошибка при запуске игры
    pause
    exit /b 1
)
```

---

## 🐛 Устранение проблем

### Проблема: "JAVA_HOME is not set"
**Решение:**
```bash
# Linux/macOS - добавить в ~/.bashrc или ~/.zshrc
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk
export PATH=$JAVA_HOME/bin:$PATH

# Windows - установить через системные переменные
# Панель управления → Система → Дополнительные параметры системы → Переменные среды
```

### Проблема: "UnsupportedClassVersionError"
**Решение:** Установите Java 21 или более новую версию

### Проблема: "OutOfMemoryError"
**Решение:** Увеличите память JVM:
```bash
java -Xmx2G -jar royal-demons.jar
```

### Проблема: "NoClassDefFoundError"
**Решение:** Убедитесь, что JAR файл содержит все зависимости:
```bash
# Пересборка с зависимостями
./gradlew shadowJar
java -jar build/libs/royal-demons-all.jar
```

### Проблема: Медленная работа
**Решение:** Оптимизируйте параметры JVM:
```bash
java -Xmx1G -Xms512M -XX:+UseG1GC -jar royal-demons.jar
```

---

## 📊 Мониторинг производительности

### Проверка использования ресурсов
```bash
# Запуск с мониторингом
java -Xmx1G -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -jar royal-demons.jar

# Мониторинг через jvisualvm (дополнительно)
jvisualvm
```

### Оптимальные параметры JVM
```bash
# Для систем с < 2GB RAM
java -Xmx512M -Xms256M -XX:+UseSerialGC -jar royal-demons.jar

# Для систем с 2-4GB RAM
java -Xmx1G -Xms512M -XX:+UseG1GC -jar royal-demons.jar

# Для систем с > 4GB RAM
java -Xmx2G -Xms1G -XX:+UseG1GC -jar royal-demons.jar
```

---

## 🔒 Безопасность

### Проверка целостности
```bash
# Создание контрольной суммы
sha256sum royal-demons.jar > royal-demons.jar.sha256

# Проверка целостности
sha256sum -c royal-demons.jar.sha256
```

### Цифровая подпись (опционально)
```bash
# Создание хранилища ключей
keytool -genkeypair -alias royal-demons -keyalg RSA -keysize 2048 -keystore keystore.jks

# Подписание JAR файла
jarsigner -keystore keystore.jks royal-demons.jar royal-demons
```

---

## 📦 Создание дистрибутива

### Структура дистрибутива
```
royal-demons-v1.0/
├── royal-demons.jar          # Основной JAR файл
├── run.sh                    # Скрипт запуска для Linux/macOS
├── run.bat                   # Скрипт запуска для Windows
├── README.txt                # Краткая инструкция
├── CHANGELOG.txt             # Список изменений
├── LICENSE.txt               # Лицензия
├── docs/                     # Документация
│   ├── README_RU.md
│   ├── RELEASE_NOTES.md
│   └── DEPLOYMENT_GUIDE.md
└── assets/                   # Дополнительные ресурсы
    └── screenshots/          # Скриншоты игры
```

### Создание архивов
```bash
# Создание tar.gz для Linux/macOS
tar -czf royal-demons-v1.0-linux.tar.gz -C royal-demons-v1.0 .

# Создание zip для Windows
zip -r royal-demons-v1.0-windows.zip royal-demons-v1.0/

# Проверка архивов
tar -tzf royal-demons-v1.0-linux.tar.gz
unzip -l royal-demons-v1.0-windows.zip
```

---

## 🌐 Распространение

### GitHub Releases
1. Создайте новый релиз на GitHub
2. Загрузите файлы:
   - `royal-demons.jar`
   - `royal-demons-v1.0-linux.tar.gz`
   - `royal-demons-v1.0-windows.zip`
3. Добавьте описание релиза
4. Свяжите с тегом `v1.0`

### Альтернативные платформы
- **Itch.io** - для инди-игр
- **GameJolt** - для инди-разработчиков
- **Steam Direct** - для коммерческого распространения

---

## 📈 Аналитика и телеметрия

### Сбор статистики (опционально)
```java
// Пример кода для сбора базовой статистики
public class GameAnalytics {
    public static void reportGameStart() {
        // Отправка анонимной статистики
        // Версия игры, ОС, время запуска
    }
    
    public static void reportSessionEnd(long playTime) {
        // Отправка времени сессии
    }
}
```

---

## 🎯 Рекомендации по развертыванию

### Для разработчиков
- Используйте Gradle для сборки и тестирования
- Включите все зависимости в JAR
- Тестируйте на разных платформах
- Создавайте скрипты для автоматизации

### Для пользователей
- Убедитесь, что установлена Java 21+
- Скачивайте только с официальных источников
- Проверяйте контрольные суммы
- Следуйте инструкциям по установке

### Для администраторов
- Развертывайте в изолированной среде
- Мониторьте использование ресурсов
- Создавайте резервные копии
- Обновляйте регулярно

---

## 📞 Поддержка

### Документация
- 📖 **Полное руководство**: [README_RU.md](README_RU.md)
- 🔧 **Техническая документация**: [INTEGRATION_GUIDE.md](INTEGRATION_GUIDE.md)
- 🚀 **Релизные заметки**: [RELEASE_NOTES.md](RELEASE_NOTES.md)

### Контакты
- 🐛 **Сообщить об ошибке**: GitHub Issues
- 💬 **Предложить улучшение**: GitHub Discussions
- 📧 **Техническая поддержка**: support@royal-demons.com

---

**Royal Demons v1.0 готов к развертыванию!** 🎮✨🇷🇺

*Следуйте этой инструкции для успешного развертывания игры.*