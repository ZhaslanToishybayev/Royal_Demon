# 🏗️ Архитектура Royal Demons

## 📋 Обзор

Royal Demons построен на модульной архитектуре, обеспечивающей:
- **Кроссплатформенность** - работа на Windows, Linux, macOS
- **Модульность** - независимые компоненты с четкими интерфейсами
- **Расширяемость** - легкое добавление новых функций
- **Тестируемость** - изолированные модули для тестирования
- **Конфигурируемость** - настройка через JSON/YAML файлы

## 🎯 Основные компоненты

```
src/main/java/uwu/openjfx/
├── core/                           # Ядро системы
│   ├── Platform.java              # Определение платформы
│   ├── ResourceManager.java       # Управление ресурсами
│   ├── GameLogger.java            # Система логирования
│   ├── ConfigManager.java         # Управление конфигурацией
│   ├── GameModule.java            # Интерфейс модуля
│   ├── ModuleManager.java         # Управление модулями
│   └── modules/                   # Базовые модули
│       ├── CoreModule.java        # Модуль ядра
│       └── AssetModule.java       # Модуль ресурсов
├── config/                        # Конфигурации
│   └── GameConfig.java            # Основная конфигурация
├── integration/                   # Интеграция систем
├── combo/                         # Система комбо
├── progression/                   # Прогрессия игрока
├── achievements/                  # Достижения
├── i18n/                         # Локализация
└── ...
```

## 🔧 Ключевые системы

### 1. Модульная система (ModuleManager)

**Назначение**: Управление загрузкой и жизненным циклом модулей

**Ключевые возможности**:
- Автоматическое разрешение зависимостей
- Топологическая сортировка инициализации
- Graceful shutdown всех модулей
- Обновление модулей в игровом цикле

**Использование**:
```java
ModuleManager moduleManager = ModuleManager.getInstance();

// Регистрация модуля
moduleManager.registerModule(new MyModule());

// Инициализация всех модулей
moduleManager.initializeAll();

// Обновление всех активных модулей
moduleManager.updateAll(tpf);

// Завершение работы
moduleManager.shutdownAll();
```

**Создание модуля**:
```java
public class MyModule implements GameModule {
    @Override
    public String getName() {
        return "MyModule";
    }

    @Override
    public void initialize() throws ModuleException {
        // Инициализация
    }

    @Override
    public void shutdown() throws ModuleException {
        // Завершение
    }
}
```

### 2. Кроссплатформенность (Platform)

**Назначение**: Абстрагирование различий между операционными системами

**Возможности**:
- Определение текущей платформы
- Нормализация путей
- Правильные директории для сохранений
- Кроссплатформенные разделители

**Использование**:
```java
// Определение платформы
if (Platform.isWindows()) {
    // Windows-специфичный код
} else if (Platform.isLinux()) {
    // Linux-специфичный код
}

// Получение директорий
String savesDir = Platform.getGameSavesDirectory();
String configDir = Platform.getGameConfigDirectory();
String logsDir = Platform.getGameLogsDirectory();

// Нормализация путей
String normalizedPath = Platform.normalizePath("path\\to\\file");
```

### 3. Управление ресурсами (ResourceManager)

**Назначение**: Кроссплатформенная загрузка ресурсов из JAR и файловой системы

**Возможности**:
- Загрузка из classpath
- Работа с JAR файлами
- Список ресурсов в директории
- Фильтрация по расширению

**Использование**:
```java
ResourceManager resourceManager = ResourceManager.getInstance();

// Загрузка ресурса
InputStream is = resourceManager.getResourceAsStream("assets/textures/player.png");

// Проверка существования
boolean exists = resourceManager.resourceExists("assets/audio/click.wav");

// Список всех файлов
List<String> images = resourceManager.listResources("assets/textures");

// Список файлов с определенным расширением
List<String> jsonFiles = resourceManager.listResourcesByExtension("config", "json");
```

### 4. Конфигурация (ConfigManager)

**Назначение**: Управление конфигурационными файлами в форматах JSON/YAML

**Возможности**:
- Автоматическое создание директорий
- Поддержка JSON и YAML
- Бэкап конфигураций
- Значения по умолчанию

**Использование**:
```java
ConfigManager configManager = ConfigManager.getInstance();

// Загрузка конфигурации
GameConfig config = configManager.loadConfig("game", GameConfig.class);

// Сохранение
configManager.saveConfig("game", config);

// Получение из кэша
GameConfig cachedConfig = configManager.getConfig("game", GameConfig.class);

// Бэкап всех конфигураций
configManager.backupConfigs();
```

### 5. Логирование (GameLogger)

**Назначение**: Централизованная система логирования

**Уровни логирования**:
- DEBUG - отладочная информация
- INFO - общая информация
- GAMEPLAY - события игрового процесса
- WARNING - предупреждения
- ERROR - ошибки
- SYSTEM - системные сообщения

**Использование**:
```java
// Логирование различных уровней
GameLogger.debug("MyModule", "Debug message");
GameLogger.info("MyModule", "Info message");
GameLogger.warning("MyModule", "Warning message");
GameLogger.error("MyModule", "Error message", exception);

// Системное логирование
GameLogger.system("Application started");

// Геймплей логирование
GameLogger.gameplay("Combat", "Player attacked enemy");
```

## 🔌 Жизненный цикл приложения

```
1. Запуск JVM
   ↓
2. Инициализация ModuleManager
   ↓
3. Регистрация CoreModule (приоритет 0)
   ↓
4. Регистрация AssetModule (приоритет 10)
   ↓
5. Регистрация других модулей
   ↓
6. Топологическая сортировка модулей
   ↓
7. Инициализация CoreModule
   ├── Создание директорий
   ├── Загрузка конфигурации
   └── Настройка логирования
   ↓
8. Инициализация AssetModule
   ├── Загрузка списков ресурсов
   └── Кэширование ассетов
   ↓
9. Инициализация других модулей
   ↓
10. Главный игровой цикл
    ├── Обновление модулей
    ├── Рендеринг
    └── Обработка ввода
    ↓
11. Завершение работы (graceful shutdown)
    ├── Завершение модулей в обратном порядке
    ├── Сохранение конфигурации
    └── Закрытие логгеров
```

## 📁 Структура директорий

### В разработке (dev mode)
```
project-root/
├── src/main/java/              # Исходный код
├── src/main/resources/         # Ресурсы
│   ├── assets/                 # Ассеты игры
│   ├── config/                 # Конфигурации
│   └── i18n/                   # Локализация
└── build/                      # Сборка
```

### В production (JAR файл)
```
royal-demons.jar
├── META-INF/
├── uwu/openjfx/                # Скомпилированные классы
└── assets/                     # Ассеты (из resources)
    ├── textures/
    ├── audio/
    └── levels/
```

### Пользовательские данные

#### Windows
```
%USERPROFILE%\Documents\
└── RoyalDemons\
    ├── config\                 # Конфигурационные файлы
    │   ├── game.json
    │   ├── controls.json
    │   └── audio.json
    ├── saves\                  # Сохранения
    │   ├── save_001.json
    │   └── save_002.json
    └── logs\                   # Логи
        └── royal-demons.log
```

#### Linux
```
~/.local/share/
└── RoyalDemons/
    ├── config/
    │   ├── game.yaml
    │   ├── controls.json
    │   └── audio.json
    ├── saves/
    │   ├── save_001.json
    │   └── save_002.json
    └── logs/
        └── royal-demons.log
```

#### macOS
```
~/Library/Application Support/
└── RoyalDemons/
    ├── config/
    ├── saves/
    └── logs/

~/Library/Preferences/
└── RoyalDemons/
    ├── game.json
    ├── controls.json
    └── audio.json
```

## 🔄 Расширение архитектуры

### Добавление нового модуля

1. **Создать класс модуля**:
```java
public class MyFeatureModule implements GameModule {
    @Override
    public String getName() { return "MyFeature"; }
    @Override
    public String getVersion() { return "1.0.0"; }
    @Override
    public String getDescription() { return "My awesome feature"; }

    @Override
    public void initialize() throws ModuleException {
        // Инициализация
    }

    @Override
    public void shutdown() throws ModuleException {
        // Завершение
    }
}
```

2. **Зарегистрировать в MainApp**:
```java
moduleManager.registerModule(new MyFeatureModule());
```

3. **Определить зависимости** (опционально):
```java
@Override
public String[] getDependencies() {
    return new String[]{"Core", "AssetModule"};
}
```

### Добавление конфигурации

1. **Создать класс конфигурации**:
```java
public class MyConfig {
    private String setting1 = "default";
    private int setting2 = 100;

    // Getters и Setters
}
```

2. **Загрузить конфигурацию**:
```java
MyConfig config = ConfigManager.getInstance().loadConfig("myconfig", MyConfig.class);
```

3. **Сохранить изменения**:
```java
config.setSetting1("new value");
ConfigManager.getInstance().saveConfig("myconfig", config);
```

## 🧪 Тестирование

### Модульное тестирование

Каждый модуль должен быть тестируем изолированно:

```java
@Test
public void testMyModuleInitialization() {
    MyModule module = new MyModule();
    assertFalse(module.isInitialized());

    module.initialize();
    assertTrue(module.isInitialized());

    module.shutdown();
    assertFalse(module.isInitialized());
}
```

### Интеграционное тестирование

Тестирование взаимодействия модулей:

```java
@Test
public void testModuleManagerIntegration() {
    ModuleManager manager = ModuleManager.getInstance();
    manager.registerModule(new CoreModule());
    manager.registerModule(new AssetModule());

    manager.initializeAll();
    assertTrue(manager.isInitialized());

    assertNotNull(manager.getModule("Core"));
    assertNotNull(manager.getModule("Assets"));

    manager.shutdownAll();
    assertFalse(manager.isInitialized());
}
```

## 📊 Производительность

### Загрузка ресурсов
- **ResourceManager** использует кэширование для списков ресурсов
- **ClassLoader** для загрузки из JAR
- **Ленивая загрузка** ассетов по требованию

### Конфигурация
- **ConfigManager** кэширует загруженные конфигурации
- **Бэкап** создается асинхронно
- **Значения по умолчанию** для быстрого старта

### Логирование
- **Асинхронная запись** в файл
- **Разделение по категориям** для фильтрации
- **Ротация логов** (планируется)

## 🔒 Безопасность

### Пути к файлам
- Все пользовательские пути проходят через `Platform` утилиты
- Нет использования абсолютных путей
- Автоматическое создание директорий с проверкой прав

### Конфигурация
- Валидация загружаемых конфигураций
- Значения по умолчанию при ошибках
- Бэкап перед обновлением

### Исключения
- Все ошибки логируются через `GameLogger`
- Graceful degradation при ошибках модулей
- Fallback к старым методам при необходимости

## 🚀 Сборка и развертывание

### Локальная сборка

**Windows**:
```cmd
build-windows.bat
```

**Linux**:
```bash
./build-linux.sh
```

### Автоматическая сборка (планируется)
```yaml
# .github/workflows/build.yml
name: Build
on: [push, pull_request]
jobs:
  build:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [windows-latest, ubuntu-latest]
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-java@v2
        with:
          java-version: '21'
      - run: ./gradlew build
```

### JAR файл
Создается в `build/libs/royal-demons.jar`:
- Содержит все зависимости (fat JAR)
- Запускается на любой системе с Java 21+
- Все ресурсы включены

## 📈 Мониторинг и метрики

### Логирование событий
- Инициализация модулей
- Загрузка ресурсов
- Ошибки конфигурации
- Производительность

### Метрики (планируется)
- Время инициализации модулей
- Использование памяти
- Частота кадров
- Время загрузки ресурсов

## 🔮 Планы развития

### v1.1 (Следующая версия)
- [ ] Система плагинов (загрузка .jar модулей)
- [ ] Автоматическое обновление модулей
- [ ] GUI для настройки конфигурации
- [ ] Веб-интерфейс для мониторинга

### v1.2
- [ ] Микросервисная архитектура
- [ ] REST API для управления игрой
- [ ] База данных для сохранений
- [ ] Облачная синхронизация

### v2.0
- [ ] Модульная компиляция (отдельные .jar для каждого модуля)
- [ ] Hot-swapping модулей
- [ ] Scripting поддержка (Python/Lua)
- [ ] Distributed architecture

## 📝 Заключение

Архитектура Royal Demons обеспечивает:
- ✅ **Надежность** - graceful shutdown, обработка ошибок
- ✅ **Масштабируемость** - модульная структура
- ✅ **Поддерживаемость** - четкое разделение ответственности
- ✅ **Тестируемость** - изолированные компоненты
- ✅ **Кроссплатформенность** - работа на всех основных ОС

Модульная архитектура позволяет легко добавлять новые функции, тестировать компоненты изолированно и поддерживать код в чистоте. Созданный фундамент готов для реализации продвинутых функций ИИ, машинного обучения и процедурной генерации.
