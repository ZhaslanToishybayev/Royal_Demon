# 📥 Инструкция по установке Java 21 для Royal Demons

## 🎯 Обзор

Для запуска игры Royal Demons требуется Java 21 или выше. Эта инструкция поможет вам установить Java 21 на Ubuntu 24.04.

---

## 🚀 Способ 1: Установка через apt (рекомендован)

### Шаг 1: Обновление пакетов
```bash
sudo apt update
```

### Шаг 2: Установка OpenJDK 21
```bash
sudo apt install openjdk-21-jdk
```

### Шаг 3: Проверка установки
```bash
java -version
javac -version
```

Ожидаемый вывод:
```
openjdk version "21.0.8" 2024-07-16
OpenJDK Runtime Environment (build 21.0.8+9-Ubuntu-1ubuntu124.04.1)
OpenJDK 64-Bit Server VM (build 21.0.8+9-Ubuntu-1ubuntu124.04.1, mixed mode, sharing)
```

### Шаг 4: Настройка переменной среды (если необходимо)
```bash
# Добавление в ~/.bashrc
echo 'export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64' >> ~/.bashrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.bashrc

# Перезагрузка ~/.bashrc
source ~/.bashrc
```

---

## 🚀 Способ 2: Установка через SDKMAN (альтернативный)

### Шаг 1: Установка SDKMAN
```bash
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"
```

### Шаг 2: Установка Java 21
```bash
sdk install java 21.0.8-open
```

### Шаг 3: Использование Java 21
```bash
sdk use java 21.0.8-open
```

### Шаг 4: Проверка установки
```bash
java -version
```

---

## 🚀 Способ 3: Ручная установка (если apt не работает)

### Шаг 1: Скачивание Java 21
```bash
cd ~/Downloads
wget https://download.java.net/java/GA/jdk21.0.8/f632425937545c1f9457b67308c2e3b8/9/GPL/openjdk-21.0.8_linux-x64_bin.tar.gz
```

### Шаг 2: Распаковка
```bash
sudo tar -xzf openjdk-21.0.8_linux-x64_bin.tar.gz -C /opt/
sudo mv /opt/jdk-21.0.8 /opt/java-21
```

### Шаг 3: Настройка переменных среды
```bash
# Создание символической ссылки
sudo update-alternatives --install /usr/bin/java java /opt/java-21/bin/java 1
sudo update-alternatives --install /usr/bin/javac javac /opt/java-21/bin/javac 1

# Добавление в ~/.bashrc
echo 'export JAVA_HOME=/opt/java-21' >> ~/.bashrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.bashrc

# Перезагрузка ~/.bashrc
source ~/.bashrc
```

### Шаг 4: Проверка установки
```bash
java -version
```

---

## 🔧 Устранение проблем

### Проблема: "command not found: java"
**Решение:**
1. Проверьте установку: `dpkg -l | grep openjdk-21`
2. Перезагрузите терминал
3. Проверьте PATH: `echo $PATH`

### Проблема: "JAVA_HOME is not set"
**Решение:**
```bash
# Найдите путь установки
dirname $(readlink -f $(which java))

# Установите JAVA_HOME
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
```

### Проблема: Несколько версий Java
**Решение:**
```bash
# Просмотр установленных версий
update-alternatives --list java

# Выбор версии по умолчанию
sudo update-alternatives --config java
```

---

## ✅ Проверка готовности

### Команды для проверки:
```bash
# Проверка версии Java
java -version

# Проверка компилятора
javac -version

# Проверка JAVA_HOME
echo $JAVA_HOME

# Проверка PATH
which java
```

### Ожидаемый результат:
- Java 21.0.8 или выше
- Корректно установленный JAVA_HOME
- Java в PATH

---

## 🚀 Запуск игры после установки Java

### Шаг 1: Переход в директорию проекта
```bash
cd ~/Downloads/Telegram\ Desktop/Royal_Demons-main
```

### Шаг 2: Сборка проекта
```bash
./gradlew clean build
```

### Шаг 3: Запуск тестов
```bash
./gradlew test
```

### Шаг 4: Создание JAR
```bash
./gradlew jar
```

### Шаг 5: Запуск игры
```bash
./gradlew run
```

---

## 📞 Поддержка

### Если возникли проблемы:
1. **Проверьте системные требования**: Ubuntu 20.04+ / 2GB RAM+
2. **Убедитесь в правах доступа**: sudo права для установки
3. **Проверьте интернет-соединение**: для скачивания пакетов
4. **Очистите кэш apt**: `sudo apt clean`

### Полезные команды:
```bash
# Проверка установленных пакетов Java
dpkg -l | grep openjdk

# Поиск файлов Java
find /usr -name "java" -type f 2>/dev/null

# Проверка переменных окружения
env | grep JAVA
```

---

## 🎉 Заключение

После установки Java 21 вы сможете:
- ✅ Скомпилировать проект Royal Demons
- ✅ Запустить тесты
- ✅ Создать JAR дистрибутив
- ✅ Играть в Royal Demons

**Java 21 - это всё, что нужно для запуска игры!** ☕🚀

---

*Следуйте этой инструкции для успешной установки Java 21.*