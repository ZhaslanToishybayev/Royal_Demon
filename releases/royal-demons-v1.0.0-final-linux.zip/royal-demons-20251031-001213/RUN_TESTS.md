# 🧪 Запуск тестов для Royal Demons

## 🚀 Как запустить тесты

### Способ 1: Все тесты
```bash
./gradlew test
```

### Способ 2: Только наш интеграционный тест
```bash
./gradlew test --tests "uwu.openjfx.IntegrationTest"
```

### Способ 3: С подробным выводом
```bash
./gradlew test --info
```

## 📋 Что проверяют тесты

### ✅ Тест 1: Локализация
- Проверка русских строк
- Проверка несуществующих ключей
- Проверка работы LocalizationManager

### ✅ Тест 2: Комбо-система
- Проверка множителей урона
- Проверка сброса комбо
- Проверка разных типов атак

### ✅ Тест 3: Система прогрессии
- Проверка начального уровня
- Проверка добавления опыта
- Проверка повышения уровня

### ✅ Тест 4: Система достижений
- Проверка начального состояния
- Проверка разблокировки
- Проверка системы достижений

### ✅ Тест 5: Интеграция
- Проверка инициализации всех систем
- Проверка работы вместе

## 📊 Ожидаемые результаты

### Успешное прохождение тестов:
```
BUILD SUCCESSFUL in Xs
X actionable tasks: X executed
```

### Результаты тестов:
```
> Task :compileJava
> Task :processResources NO-SOURCE
> Task :classes
> Task :compileTestJava
> Task :processTestResources NO-SOURCE
> Task :testClasses
> Task :test

uwu.openjfx.IntegrationTest > testLocalizationManager PASSED
uwu.openjfx.IntegrationTest > testComboSystem PASSED
uwu.openjfx.IntegrationTest > testProgressionSystem PASSED
uwu.openjfx.IntegrationTest > testAchievementsSystem PASSED
uwu.openjfx.IntegrationTest > testGameIntegration PASSED
uwu.openjfx.IntegrationTest > testComboMultiplier PASSED
uwu.openjfx.IntegrationTest > testProgressionLevelUp PASSED
uwu.openjfx.IntegrationTest > testAchievementsCheck PASSED

BUILD SUCCESSFUL
```

## 🔧 Если тесты не проходят

### Проблема 1: Ошибки компиляции
```bash
./gradlew clean build
./gradlew test
```

### Проблема 2: Тесты не находят классы
```bash
./gradlew clean
./gradlew build
./gradlew test --tests "uwu.openjfx.*"
```

### Проблема 3: Ошибки в тестах
Проверьте консоль на наличие конкретных ошибок и исправьте их.

## 📈 Покрытие кода

Тесты проверяют основные функции:
- ✅ Локализация (LocalizationManager)
- ✅ Комбо-система (SimpleComboSystem)
- ✅ Прогрессия (SimpleProgression)
- ✅ Достижения (SimpleAchievements)
- ✅ Интеграция (GameIntegration)

## 🎯 Цель тестирования

1. **Убедиться, что все системы работают**
2. **Проверить интеграцию между системами**
3. **Гарантировать стабильность проекта**
4. **Подтвердить готовность к демонстрации**

## 🚀 Запускайте тесты!

```bash
./gradlew test
```

**Все тесты должны пройти успешно!** ✅