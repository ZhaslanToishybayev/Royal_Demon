# Кроссплатформенная сборка Royal Demons

## 📋 Системные требования

### Windows
- **Java**: OpenJDK 21+ или Oracle JDK 21+
- **OS**: Windows 10/11 (64-bit)
- **RAM**: 512 MB доступной памяти
- **GPU**: Любая поддерживающая OpenGL 2.0+

### Linux
- **Java**: OpenJDK 21+
- **OS**: Ubuntu 18.04+, Fedora 30+, или любой дистрибутив с GLIBC 2.17+
- **RAM**: 512 MB доступной памяти
- **GPU**: Любая поддерживающая OpenGL 2.0+

## 🚀 Быстрый запуск

### Windows
1. Двойной клик по `build-windows.bat`
2. Дождитесь завершения сборки
3. Двойной клик по `run-windows.bat`

### Linux
```bash
chmod +x build-linux.sh run-linux.sh
./build-linux.sh
./run-linux.sh
```

## 🛠️ Детальная сборка

### Windows
```cmd
# Полная сборка с тестами
gradlew.bat build

# Сборка без тестов (быстро)
gradlew.bat build -x test

# Только компиляция
gradlew.bat compileJava

# Запуск тестов
gradlew.bat test

# Проверка стиля кода
gradlew.bat checkstyleMain checkstyleTest

# Анализ кода
gradlew.bat spotbugsMain spotbugsTest

# Создание JAR
gradlew.bat jar

# Запуск игры
gradlew.bat run
```

### Linux
```bash
# Полная сборка с тестами
./gradlew build

# Сборка без тестов (быстро)
./gradlew build -x test

# Только компиляция
./gradlew compileJava

# Запуск тестов
./gradlew test

# Проверка стиля кода
./gradlew checkstyleMain checkstyleTest

# Анализ кода
./gradlew spotbugsMain spotbagsTest

# Создание JAR
./gradlew jar

# Запуск игры
./gradlew run
```

## 📁 Структура файлов

```
RoyalDemons/
├── build-windows.bat       # Скрипт сборки для Windows
├── build-linux.sh          # Скрипт сборки для Linux
├── run-windows.bat         # Запуск игры в Windows
├── run-linux.sh            # Запуск игры в Linux
├── build.gradle            # Конфигурация сборки
├── src/                    # Исходный код
├── build/libs/             # Собранные JAR файлы
└── logs/                   # Логи игры (создается автоматически)
```

## 🔧 Конфигурация

### Расположение файлов конфигурации

#### Windows
- **Конфигурация**: `%USERPROFILE%\Documents\RoyalDemons\config\`
- **Сохранения**: `%USERPROFILE%\Documents\RoyalDemons\saves\`
- **Логи**: `%USERPROFILE%\Documents\RoyalDemons\logs\`

#### Linux
- **Конфигурация**: `~/.config/RoyalDemons/`
- **Сохранения**: `~/.local/share/RoyalDemons/saves/`
- **Логи**: `~/.local/share/RoyalDemons/logs/`

#### macOS
- **Конфигурация**: `~/Library/Preferences/RoyalDemons/`
- **Сохранения**: `~/Library/Application Support/RoyalDemons/saves/`
- **Логи**: `~/Library/Logs/RoyalDemons/`

### Файлы конфигурации
- `game.json` - Основные настройки игры
- `controls.json` - Настройки управления
- `audio.json` - Настройки звука

## 🐛 Отладка

### Просмотр логов
Логи автоматически сохраняются в директорию логов и выводятся в консоль.

### Включение debug-режима
Отредактируйте файл `config/game.json`:
```json
{
  "enableDebugMode": true
}
```

### Проблемы и решения

#### Java не найдена
**Windows**: Убедитесь, что Java добавлена в PATH
```cmd
java -version
```

**Linux**: Установите OpenJDK 21+
```bash
# Ubuntu/Debian
sudo apt install openjdk-21-jdk

# Fedora/RHEL
sudo dnf install java-21-openjdk-devel
```

#### Ошибка "Unable to load native library"
Убедитесь, что установлена актуальная версия JavaFX совместимая с вашей системой.

#### Низкая производительность
- Закройте другие ресурсоемкие приложения
- Уменьшите настройки графики в `game.json`
- Попробуйте запустить с параметром: `java -Xmx512m -jar royal-demons.jar`

## 📦 Создание дистрибутива

### Создание ZIP-архива (Windows)
```cmd
gradlew.bat distZip
# Создается build/distributions/royal-demons.zip
```

### Создание TAR.GZ архива (Linux)
```bash
./gradlew distZip
# Создается build/distributions/royal-demons.zip (универсальный)
```

## 🔍 Проверка сборки

### Автоматические проверки
Проект настроен на автоматическую проверку:
- **Checkstyle** - стиль кода
- **SpotBugs** - статический анализ
- **JUnit** - юнит-тесты

### Ручная проверка
```bash
# Проверка стиля
./gradlew checkstyle

# Анализ кода
./gradlew spotbugs

# Запуск тестов
./gradlew test
```

## 💾 Технические детали

### Используемые технологии
- **Java**: 21
- **FXGL**: 17.3
- **JavaFX**: 21.0.2
- **Jackson**: 2.15.2 (JSON/YAML)
- **JUnit**: 5.10.1

### Платформенно-специфичные особенности
- Автоматическое определение ОС через `Platform.java`
- Кроссплатформенная загрузка ресурсов через `ResourceManager`
- Правильные пути к конфигурациям для каждой ОС
- Fallback к старому методу загрузки ресурсов при необходимости

## 📞 Поддержка

Если у вас возникли проблемы:
1. Проверьте логи в директории логов
2. Убедитесь, что установлена Java 21+
3. Попробуйте пересобрать проект
4. Проверьте наличие прав записи в директорию конфигураций

## 📄 Лицензия

Проект создан в учебных целях.
